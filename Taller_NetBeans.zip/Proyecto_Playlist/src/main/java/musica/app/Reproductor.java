package musica.app;

import java.util.ArrayList;
import musica.modelo.Cancion;
import musica.modelo.Playlist;

public class Reproductor {
    public static void main(String[] args) {
        Cancion c1 = new Cancion("Lluvia en Manizales", "Nevado", 200);
        Cancion c2 = new Cancion("Bajo el guadual", "Café Trío", 245);
        Cancion c3 = new Cancion("Noche en Chipre", "Nevado", 185);

        Playlist fav = new Playlist("Favoritas");
        fav.agregar(c1); fav.agregar(c2); fav.agregar(c3);
        System.out.println(fav.agregar(c1));
        fav.mostrar();
        System.out.println(fav.duracionTotal());

        Playlist viaje = new Playlist("Viaje");
        viaje.agregar(c1); viaje.agregar(c2);
        System.out.println(fav.eliminarArtista("Nevado"));
        fav.mostrar();
        viaje.mostrar();
        System.out.println(fav.buscar("bajo el guadual").getArtista());
        System.out.println(fav.buscar("Lluvia en Manizales"));

        Cancion c4 = new Cancion("Río Chinchiná", "Nevado", 230);
        System.out.println(viaje.agregar(c3));
        System.out.println(viaje.agregar(c4));
        System.out.println(Cancion.getTotalCanciones());
        System.out.println(Playlist.MAX_CANCIONES);

        // Reto 1: no se debe modificar una colección dentro de for-each.
        try {
            viaje.eliminarArtistaConForEach("Nevado");
        } catch (java.util.ConcurrentModificationException e) {
            System.out.println(e.getClass().getName());
            System.out.println("No se puede modificar estructuralmente la lista durante for-each.");
        }

        // Reto 2
        Cancion larga = fav.cancionMasLarga();
        System.out.println(larga == null ? "Sin canciones" : larga.getTitulo());

        // Reto 3: limpiar la copia no modifica la playlist original.
        ArrayList<Cancion> copia = viaje.getCanciones();
        copia.clear();
        System.out.println("Canciones en Viaje después de limpiar copia: " + viaje.getCanciones().size());

        // Reto 5: referencias repetidas y objetos distintos.
        ArrayList<Cancion> lista = new ArrayList<>();
        Cancion x = new Cancion("A", "Uno", 100);
        lista.add(x);
        lista.add(x);
        lista.add(new Cancion("A", "Uno", 100));
        System.out.println(lista.size());
        System.out.println(lista.get(0) == lista.get(1));
        System.out.println(lista.get(0) == lista.get(2));
        lista.remove(x);
        System.out.println(lista.size());
        System.out.println(lista.contains(x));
    }
}
